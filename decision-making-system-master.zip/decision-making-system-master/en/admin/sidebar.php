

<div id="sidebar">
	<div class="navbox" style="margin-top: 30px;">
		<ul class="nav">
                        <li><a href="main.php">Home</a></li>
                        <li><a href="create_research.php">Create Research</a></li>
                        <li><a href="delete_research.php">Delete Research</a></li>
                        <li><a href="research_to_user.php">Set User To Research</a></li>
                        <li><a href="edit_publish.php">Edit and Publish Research</a></li>
                        <li><a href="preview_research.php">Preview Research</a></li>
			<li><a href="#">Previous Researches</a></li>
                        <li><a href="generate_results.php">Extract Results</a></li>
                        <li><a href="logout.php">Logout</a></li>
		</ul>
	</div>
</div>