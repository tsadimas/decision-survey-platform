<?php
include_once "header.php";
?>


<!----------------------CONTENT---------------------->
	
		<h1> Welcome to Decision Maker </h1> 
		<h2> Please select an action from the sidebar </h2>


<?php
include_once "footer.php";
?>