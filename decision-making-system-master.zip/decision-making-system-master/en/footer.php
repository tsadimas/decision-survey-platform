</div>
</div>
</div>
</div>
</div>

<!--END OF ARTICLE--->

<div id="templatemo_footer_wrapper">

    <div id="templatemo_footer">
        <p>Copyright © 2014 <a href="">Harokopeion University</a> - <a href="">Department of Informatics and TElematics</a> | Designed by <a href="https://www.facebook.com/dimitris.alexandrakis.73" target="_blank">Alexandrakis Dimitris</a></p>
        <p>CSS by Templetemo Free CSS Teplates</p>
    </div>
</div>

</body> 
</html>